"use client"
const Error = () =>{
    return (
        <div>Error</div>
    )
    }
    
    export default Error