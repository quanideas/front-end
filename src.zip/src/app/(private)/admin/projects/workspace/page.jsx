import ProjectWorkspace from '@/components/layout/projectWorkspaceLayout/ProjectWorkspaceLayout';

const Project = () => {
  return (
    <div>
      <ProjectWorkspace/>
    </div>

  );
};

export default Project;
