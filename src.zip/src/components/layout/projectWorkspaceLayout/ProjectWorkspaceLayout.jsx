import Navigator from '@/components/common/projectWorkspace/navigator/Navigator';

const ProjectWorkspace = () => {
    return (
      <div>
        <Navigator/>
      </div>
  
    );
  };
  
  export default ProjectWorkspace;