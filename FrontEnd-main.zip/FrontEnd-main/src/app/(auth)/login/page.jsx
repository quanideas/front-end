"use client"
import React from 'react';
import LoginForm from '../../../components/pages/login/login/Login';

export default function Login() {
    return (
        <LoginForm />
    );
  }