import LoadingPage from '@/components/common/loadingPage/LoadingPage';
const Loading = () =>{
    return (
        <LoadingPage />
    )
    }
    
    export default Loading